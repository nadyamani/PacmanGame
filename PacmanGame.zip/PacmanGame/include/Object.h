#pragma once
#include <SFML/Graphics.hpp>

class Object {
public:
	Object();
	//virtual void DrawToWindow(std::vector<std::unique_ptr<Object>>& m_moving, sf::RenderWindow& window) = 0;

private:

};