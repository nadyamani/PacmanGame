enum class enumObj{
	PACMAN_CH = 'a',
	GHOST_CH = '&',
	DOOR_CH = 'D',
	KEY_CH = '%',
	CAKE_CH = '*',
	GIFT_CH = '$',
	WALL_CH = '#',
};