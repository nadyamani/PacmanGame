#include "MovingObj.h"
MovingObj::MovingObj()
{}
