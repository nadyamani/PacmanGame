#include "StaticObj.h"

StaticObj::StaticObj()
{}
